#-*- coding: utf-8 -*-

import urllib2
from bs4 import BeautifulSoup

file = "test.csv"

def get_html():

    readline = []
    with open("./test.csv", "r") as ins:
        readline = ins.readlines()

    for link in readline:
        if len(link) > 10:
            link = link.strip().replace("\n", "")
            print("-------------------------------------------------------------------------------------------")
            print(link)


            res = urllib2.urlopen(link)
            html = res.read()
            res.close()
            inner_soup = BeautifulSoup(html, 'html.parser')
            # print inner_soup

            em = inner_soup.find('div', {"class": "items_left"}).find('em')
            if em is not None:
                print em.get_text().strip().replace("items left", "").strip()
            else:
                print 0

get_html()